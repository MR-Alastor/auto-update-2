if not ReloadChanger then
    log("[ReloadChanger] Error: ReloadChanger not found")
    return
end

if not MenuCallbackHandler then
    log("[ReloadChanger] Error: MenuCallbackHandler is nil")
    return
end


local function AddModOptions(menu_manager)
    if menu_manager == nil then
        return
    end


    MenuCallbackHandler.ReloadChanger_SaveSettings = function(node)
        ReloadChanger:Save()
    end
    

    MenuCallbackHandler.set_reload_multiplier = function(self, item)
        ReloadChanger.Settings.reload_multiplier = item:value()

        log("[ReloadChanger] Multiplier changed to: " .. item:value())
    end
    

    MenuCallbackHandler.toggle_reload_mod = function(self, item)
        ReloadChanger.Settings.enabled = (item:value() == "on")
    end
    

    MenuCallbackHandler.reset_reload_settings = function(self, item)
        ReloadChanger:Reset()
        

        local menu = managers.menu:active_menu()
        if menu and menu.logic then
            local node = menu.logic:selected_node()
            if node then
                for _, menu_item in ipairs(node:items()) do
                    if menu_item:name() == "sld_reload_multiplier" then
                        menu_item:set_value(0.5)
                    elseif menu_item:name() == "toggle_reload_enabled" then
                        menu_item:set_value(true)
                    end
                end
            end
        end
    end
    

    MenuCallbackHandler.ReloadChanger_Focus = function(node)

    end


    MenuHelper:LoadFromJsonFile(ReloadChanger.ModOptions, ReloadChanger, ReloadChanger.Settings)
end


Hooks:Add("MenuManagerInitialize", "ReloadChanger_AddModOptions", AddModOptions)