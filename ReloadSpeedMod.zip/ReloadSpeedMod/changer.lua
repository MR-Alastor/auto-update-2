_G.ReloadChanger = _G.ReloadChanger or {}

ReloadChanger.ModPath = ModPath
ReloadChanger.SaveFile = SavePath .. "reload_changer.txt"


ReloadChanger.Settings = {
    reload_multiplier = 0.5,
    enabled = true
}


function ReloadChanger:Load()
    local file = io.open(self.SaveFile, "r")
    if file then
        for key, value in pairs(json.decode(file:read("*all"))) do
            self.Settings[key] = value
        end
        file:close()
    else
        self:Save()  
    end
end


function ReloadChanger:Save()
    local file = io.open(self.SaveFile, "w+")
    if file then
        file:write(json.encode(self.Settings))
        file:close()
    end
end


function ReloadChanger:Reset()
    self.Settings = {
        reload_multiplier = 0.5,
        enabled = true
    }
    self:Save()
end


ReloadChanger:Load()


if RequiredScript == "lib/units/weapons/newraycastweaponbase" then
    local orig_reload_speed = NewRaycastWeaponBase.reload_speed_multiplier
    
    function NewRaycastWeaponBase:reload_speed_multiplier()
        if not ReloadChanger.Settings.enabled then
            if orig_reload_speed then
                return orig_reload_speed(self)
            end
            return 1.0
        end
        
        local base_speed = 1.0
        if orig_reload_speed then
            base_speed = orig_reload_speed(self)
        end
        
        return base_speed / ReloadChanger.Settings.reload_multiplier
    end
    

    local orig_start_reload = NewRaycastWeaponBase.start_reload
    if orig_start_reload then
        function NewRaycastWeaponBase:start_reload()
            local result = orig_start_reload(self)
            
            if result and ReloadChanger.Settings.enabled then
                if self._reload_expire_t then
                    local current_time = Application:time()
                    local time_left = self._reload_expire_t - current_time
                    
                    if time_left > 0 then
                        self._reload_expire_t = current_time + (time_left * ReloadChanger.Settings.reload_multiplier)
                    end
                end
            end
            
            return result
        end
    end
    
    log("[ReloadChanger] Hooks applied. Multiplier: " .. ReloadChanger.Settings.reload_multiplier)
end