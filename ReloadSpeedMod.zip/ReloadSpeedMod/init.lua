_G.ReloadChanger = _G.ReloadChanger or {}

ReloadChanger.ModPath = ModPath
ReloadChanger.SaveFile = SavePath .. "reload_changer.txt"
ReloadChanger.ModOptions = ReloadChanger.ModPath .. "menus/modoptions.txt"
ReloadChanger.Settings = {}


function ReloadChanger:Reset()
    self.Settings = {
        reload_multiplier = 0.5,
        enabled = true
    }
    self:Save()
end


Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_ReloadChanger", function(loc)
    for _, filename in pairs(file.GetFiles(ReloadChanger.ModPath .. "loc/")) do
        local str = filename:match('^(.*).txt$')
        if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
            loc:load_localization_file(ReloadChanger.ModPath .. "loc/" .. filename)
            break
        end
    end
    
    loc:load_localization_file(ReloadChanger.ModPath .. "loc/english.txt", false)
end)


function ReloadChanger:Load()
    local file = io.open(self.SaveFile, "r")
    if file then
        for key, value in pairs(json.decode(file:read("*all"))) do
            self.Settings[key] = value
        end
        file:close()
    else
        self:Reset()
    end
end


function ReloadChanger:Save()
    local file = io.open(self.SaveFile, "w+")
    if file then
        file:write(json.encode(self.Settings))
        file:close()
    end
end


ReloadChanger:Load()