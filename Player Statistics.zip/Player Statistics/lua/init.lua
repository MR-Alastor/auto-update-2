_G.Venom = _G.Venom or {}
Venom.ModPath = ModPath
Venom.SaveFile = SavePath .. "Venom.txt"
Venom.ModOptions = Venom.ModPath .. "menus/modoptions.txt"
Venom.Settings = {}

function Venom:Reset()
    -- СБРОС НА СТАНДАРТНЫЕ ЗНАЧЕНИЯ ИГРЫ
    self.Settings = {
        -- Настройки скрытности (первыми)
        enable_min_stealth = false,            -- Минимальная скрытность выключена
        enable_max_stealth = false,            -- Максимальная скрытность выключена
        enable_stealth_reset = false,          -- Сброс скрытности к стандартам игры
        
        -- Остальные настройки
        armor_multiplier = 1.0,                -- Стандартная броня
        health_multiplier = 1.0,               -- Стандартное здоровье
        health_regen = 0.0,                    -- Нет регенерации по умолчанию
        ammo_multiplier = 1.0,                 -- Стандартные патроны
        critical_chance = 0.0,                 -- Нет критов по умолчанию
        stamina_multiplier = 1.0,              -- Стандартная выносливость
        passive_dodge = 0.0,                   -- Нет уклонения по умолчанию
        run_dodge = 0.0,                       -- Нет уклонения в беге по умолчанию
        movement_speed = 1.0,                  -- Стандартная скорость
        damage_multiplier = 1.0,               -- Стандартный урон
        damage_shake_multiplier = 1.0          -- Стандартная тряска камеры
    }
    self:Save()
    log("[Venom] Settings reset to GAME DEFAULTS")
end

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_Venom", function(loc)
    local lang_key = SystemInfo:language():key()
    local loc_files = file.GetFiles(Venom.ModPath .. "loc/")
    
    for _, filename in pairs(loc_files) do
        local str = filename:match('^(.*).txt$')
        if str then
            local file_id = Idstring(str)
            if file_id and file_id:key() == lang_key then
                loc:load_localization_file(Venom.ModPath .. "loc/" .. filename)
                break
            end
        end
    end
    
    loc:load_localization_file(Venom.ModPath .. "loc/english.txt", false)
end)

function Venom:Load()
    local file = io.open(self.SaveFile, "r")
    if file then
        local data = file:read("*all")
        file:close()
        
        if data and data ~= "" then
            local success, settings = pcall(json.decode, data)
            if success and settings then
                -- Убедимся, что все ключи существуют
                for key, default_value in pairs(self:GetDefaultSettings()) do
                    if settings[key] == nil then
                        settings[key] = default_value
                    end
                end
                self.Settings = settings
                log("[Venom] Settings loaded from file")
            else
                log("[Venom] Failed to decode settings, resetting to game defaults")
                self:Reset()
            end
        else
            log("[Venom] Settings file empty, resetting to game defaults")
            self:Reset()
        end
    else
        log("[Venom] No settings file found, resetting to game defaults")
        self:Reset()
    end
end

function Venom:GetDefaultSettings()
    -- Значения по умолчанию при первом запуске
    return {
        -- Настройки скрытности (первыми)
        enable_min_stealth = false,            -- Минимальная скрытность выключена
        enable_max_stealth = false,            -- Максимальная скрытность выключена
        enable_stealth_reset = false,          -- Сброс скрытности к стандартам игры
        
        -- Остальные настройки
        armor_multiplier = 20.0,               -- 20x броня
        health_multiplier = 0.9,               -- 90% здоровья
        health_regen = 0.05,                   -- 5% регенерации
        ammo_multiplier = 4.5,                 -- 4.5x патронов
        critical_chance = 0.10,                -- 10% критов
        stamina_multiplier = 5.0,              -- 5x выносливость
        passive_dodge = 0.35,                  -- 35% уклонение
        run_dodge = 0.55,                      -- 55% уклонение в беге
        movement_speed = 1.0,                  -- Стандартная скорость
        damage_multiplier = 1.1,               -- 10% доп урона
        damage_shake_multiplier = 0.7          -- 30% меньше тряски камеры
    }
end

function Venom:Save()
    local file = io.open(self.SaveFile, "w+")
    if file then
        file:write(json.encode(self.Settings))
        file:close()
        log("[Venom] Settings saved")
    else
        log("[Venom] ERROR: Could not save settings!")
    end
end

Venom:Load()
log("[Venom] Mod initialized")