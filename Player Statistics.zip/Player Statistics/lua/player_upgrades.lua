if not Venom then
    dofile(ModPath .. "lua/init.lua")
end

if not Venom.Settings then
    Venom:Load()
end

if not _Venom_upgradeValue then
    _Venom_upgradeValue = PlayerManager.upgrade_value
    log("[Venom] Original upgrade_value function saved")
end

function PlayerManager:upgrade_value(category, upgrade, default)
    -- Check if settings are loaded
    if Venom and Venom.Settings then
        -- Use settings from menu (direct multipliers)
        if category == "player" and upgrade == "armor_multiplier" then
            return Venom.Settings.armor_multiplier or 20.0
        elseif category == "player" and upgrade == "health_multiplier" then
            return Venom.Settings.health_multiplier or 0.9
        elseif category == "player" and upgrade == "passive_health_regen" then
            return Venom.Settings.health_regen or 0.05
        elseif category == "player" and upgrade == "pick_up_ammo_multiplier" then
            return Venom.Settings.ammo_multiplier or 4.5
        elseif category == "player" and upgrade == "critical_hit_chance" then
            return Venom.Settings.critical_chance or 10.0
        elseif category == "player" and upgrade == "stamina_multiplier" then
            return Venom.Settings.stamina_multiplier or 5.0
        elseif category == "player" and upgrade == "passive_dodge_chance" then
            return Venom.Settings.passive_dodge or 0.35
        elseif category == "player" and upgrade == "run_dodge_chance" then
            return Venom.Settings.run_dodge or 0.55
        elseif category == "player" and upgrade == "movement_speed_multiplier" then
            return Venom.Settings.movement_speed or 1.0
        elseif category == "player" and upgrade == "passive_damage_multiplier" then
            return Venom.Settings.damage_multiplier or 1.1
        elseif category == "player" and upgrade == "damage_shake_multiplier" then
            return Venom.Settings.damage_shake_multiplier or 0.7
        -- Новые параметры скрытности (из mouse2tointerupt.lua)
        elseif category == "player" and upgrade == "pick_lock_speed_multiplier" then
            return Venom.Settings.pick_lock_speed_multiplier or 0.1
        elseif category == "player" and upgrade == "corpse_dispose_speed_multiplier" then
            return Venom.Settings.corpse_dispose_speed_multiplier or 0.1
        elseif category == "player" and upgrade == "alarm_pager_speed_multiplier" then
            return Venom.Settings.alarm_pager_speed_multiplier or 0.1
        end
    end
    
    -- Если настройки не загружены или параметр не найден, используем стандартное значение
    return _Venom_upgradeValue(self, category, upgrade, default)
end

log("[Venom] Player upgrades hook loaded successfully")