-- Файл для улучшений скрытности
if not Venom then
    dofile(ModPath .. "lua/init.lua")
end

-- Сохраняем оригинальную функцию
if not _Venom_visibility_modifiers then
    _Venom_visibility_modifiers = BlackMarketManager.visibility_modifiers
end

function BlackMarketManager:visibility_modifiers()
    if Venom and Venom.Settings then
        -- Режим сброса скрытности к стандартам игры
        if Venom.Settings.enable_stealth_reset then
            return _Venom_visibility_modifiers(self)  -- Используем оригинальную логику
        end
        
        -- Режим минимальной видимости (3)
        if Venom.Settings.enable_min_stealth then
            return -999  -- Минимальная видимость (около 3)
        -- Режим максимальной видимости (75)
        elseif Venom.Settings.enable_max_stealth then
            return 75    -- Максимальная видимость (75)
        end
    end
    -- Если все режимы выключены, используем стандартное значение
    return _Venom_visibility_modifiers(self)
end

log("[Venom] Stealth tweaks loaded successfully")