if not Venom then
    log("[Venom] ERROR: Failed to create Mod Options menu, aborting")
    return
end

if not MenuCallbackHandler then
    log("[Venom] ERROR: MenuCallbackHandler is nil, aborting")
    return
end

local function AddModOptions(menu_manager)
    if menu_manager == nil then
        log("[Venom] ERROR: menu_manager is nil")
        return
    end
    
    log("[Venom] Adding mod options menu")

    MenuCallbackHandler.Venom_SaveSettings = function(node)
        log("[Venom] Saving settings...")
        Venom:Save()
    end
    
    -- Функция для сброса настроек к стандартным значениям игры
    MenuCallbackHandler.reset_to_defaults = function(node)
        log("[Venom] Resetting ALL settings to GAME DEFAULTS...")
        
        -- Сбрасываем настройки к стандартным значениям игры
        Venom:Reset()
        
        -- Показываем сообщение
        if QuickMenu then
            QuickMenu:new(
                "Venom Mod",
                "ALL settings reset to GAME DEFAULTS!",
                {
                    {
                        text = "OK",
                        is_cancel_button = true
                    }
                },
                true
            )
        end
        
        log("[Venom] All settings reset to game defaults")
        
        -- Принудительно перезагружаем меню
        DelayedCalls:Add("Venom_ReloadMenu", 0.1, function()
            if MenuCallbackHandler and MenuCallbackHandler.Venom_SaveSettings then
                MenuCallbackHandler.Venom_SaveSettings(node)
            end
        end)
    end

    -- Callback функции для чекбоксов скрытности
    MenuCallbackHandler.set_enable_min_stealth = function(self, item)
        if item and item:value() ~= nil then
            Venom.Settings.enable_min_stealth = item:value()
            -- Если включаем минимальную скрытность, выключаем максимальную и сброс
            if item:value() then
                Venom.Settings.enable_max_stealth = false
                Venom.Settings.enable_stealth_reset = false
            end
            Venom:Save()
        end
    end

    MenuCallbackHandler.set_enable_max_stealth = function(self, item)
        if item and item:value() ~= nil then
            Venom.Settings.enable_max_stealth = item:value()
            -- Если включаем максимальную скрытность, выключаем минимальную и сброс
            if item:value() then
                Venom.Settings.enable_min_stealth = false
                Venom.Settings.enable_stealth_reset = false
            end
            Venom:Save()
        end
    end
    
    -- Новая функция для сброса скрытности к стандартам игры
    MenuCallbackHandler.set_enable_stealth_reset = function(self, item)
        if item and item:value() ~= nil then
            Venom.Settings.enable_stealth_reset = item:value()
            -- Если включаем сброс скрытности, выключаем другие режимы
            if item:value() then
                Venom.Settings.enable_min_stealth = false
                Venom.Settings.enable_max_stealth = false
            end
            Venom:Save()
        end
    end

    -- Callback functions for each slider
    MenuCallbackHandler.set_armor_multiplier = function(self, item)
        if item and item:value() then
            Venom.Settings.armor_multiplier = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_health_multiplier = function(self, item)
        if item and item:value() then
            Venom.Settings.health_multiplier = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_health_regen = function(self, item)
        if item and item:value() then
            Venom.Settings.health_regen = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_ammo_multiplier = function(self, item)
        if item and item:value() then
            Venom.Settings.ammo_multiplier = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_critical_chance = function(self, item)
        if item and item:value() then
            Venom.Settings.critical_chance = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_stamina_multiplier = function(self, item)
        if item and item:value() then
            Venom.Settings.stamina_multiplier = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_passive_dodge = function(self, item)
        if item and item:value() then
            Venom.Settings.passive_dodge = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_run_dodge = function(self, item)
        if item and item:value() then
            Venom.Settings.run_dodge = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_movement_speed = function(self, item)
        if item and item:value() then
            Venom.Settings.movement_speed = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_damage_multiplier = function(self, item)
        if item and item:value() then
            Venom.Settings.damage_multiplier = item:value()
            Venom:Save()
        end
    end
    
    MenuCallbackHandler.set_damage_shake_multiplier = function(self, item)
        if item and item:value() then
            Venom.Settings.damage_shake_multiplier = item:value()
            Venom:Save()
        end
    end

    -- Load menu
    if MenuHelper then
        MenuHelper:LoadFromJsonFile(Venom.ModOptions, Venom, Venom.Settings)
        log("[Venom] Mod options menu loaded successfully")
    else
        log("[Venom] ERROR: MenuHelper is nil!")
    end
end

Hooks:Add("MenuManagerInitialize", "Venom_AddModOptions", AddModOptions)
log("[Venom] Menu hook added")